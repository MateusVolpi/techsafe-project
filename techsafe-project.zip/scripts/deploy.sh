#!/usr/bin/env bash
set -euo pipefail

echo ">> Etapa 1: checando cluster"
kubectl cluster-info >/dev/null

echo ">> Instalar/atualizar microsserviços"
helm upgrade --install frontend ./techsafe-app -f values-frontend.yaml
helm upgrade --install usuarios ./techsafe-app -f values-usuarios.yaml

echo ">> Aplicando Istio (Gateway/VirtualService)"
kubectl apply -f istio/gateway.yaml
kubectl apply -f istio/virtualservice.yaml

echo ">> (Opcional) Backups: aplicar PVC e CronJob (requer secret preenchido)"
# kubectl apply -f k8s/backup/secret-db.template.yaml
kubectl apply -f k8s/backup/pvc.yaml
kubectl apply -f k8s/backup/cronjob-postgres-backup.yaml

echo ">> Done!"
