# Etapa 1 — Comandos de Configuração do Cluster

```bash
# 0) abrir o projeto (WSL)
cd ~/techsafe
code .

# 1) verificar Docker
docker ps

# 2) iniciar Minikube (ajuste memória/CPU conforme sua máquina)
minikube delete -y || true
minikube start --driver=docker --memory=3500 --cpus=2

# 3) configurar kubectl para usar minikube
kubectl config use-context minikube

# 4) verificar status do cluster
minikube status
kubectl get nodes
kubectl get pods -A

# 5) instalar Istio (se o cluster foi recriado)
istioctl install --set profile=demo -y
kubectl label namespace default istio-injection=enabled --overwrite
kubectl get pods -n istio-system
```
