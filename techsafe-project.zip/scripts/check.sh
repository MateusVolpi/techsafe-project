#!/usr/bin/env bash
set -euo pipefail
echo "=== Cluster ==="
minikube status || true
kubectl get nodes
echo
echo "=== Releases ==="
helm list
echo
echo "=== Workloads ==="
kubectl get pods,svc
echo
echo "=== Istio ==="
kubectl get gateway,virtualservice || true
echo
echo "=== CronJobs ==="
kubectl get cronjobs || true
