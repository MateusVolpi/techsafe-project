#!/usr/bin/env bash
set -euo pipefail
echo ">> Removendo releases Helm"
helm uninstall frontend || true
helm uninstall usuarios || true

echo ">> Removendo Istio routes"
kubectl delete -f istio/virtualservice.yaml --ignore-not-found
kubectl delete -f istio/gateway.yaml --ignore-not-found

echo ">> Removendo recursos de backup"
kubectl delete -f k8s/backup/cronjob-postgres-backup.yaml --ignore-not-found
kubectl delete -f k8s/backup/pvc.yaml --ignore-not-found
kubectl delete secret db-backup-secret --ignore-not-found

echo ">> Pronto."
