# Techsafe — Projeto Kubernetes com Minikube, Helm, Istio e Backups

Este repositório implementa as **três etapas** solicitadas:

1. **Configuração do Cluster Kubernetes (Minikube)**  
2. **Implantação de Microsserviços com Helm**  
3. **Liveness Probes e Backup Automatizado (CronJob + PVC)**

> Ambiente alvo: **WSL2 + Docker + Minikube + kubectl + Helm + Istio + VS Code**.

---

## 📦 Estrutura

```
techsafe/
├─ stage1/commands.md
├─ techsafe-app/                 # Chart Helm genérico (usa values por serviço)
│  ├─ Chart.yaml
│  ├─ values.yaml
│  └─ templates/
│     ├─ _helpers.tpl
│     ├─ deployment.yaml
│     ├─ service.yaml
│     ├─ configmap.yaml
│     └─ hpa.yaml
├─ values-frontend.yaml          # values do microserviço frontend (nginx)
├─ values-usuarios.yaml          # values do microserviço usuarios (httpbin de exemplo)
├─ istio/
│  ├─ gateway.yaml
│  └─ virtualservice.yaml
├─ k8s/backup/
│  ├─ secret-db.template.yaml
│  ├─ pvc.yaml
│  └─ cronjob-postgres-backup.yaml
└─ scripts/
   ├─ deploy.sh
   ├─ destroy.sh
   └─ check.sh
```

---

## ✅ Etapa 1 — Configuração do Cluster (Minikube)

Siga **stage1/commands.md**. Resumo:

```bash
docker ps
minikube delete -y || true
minikube start --driver=docker --memory=3500 --cpus=2
kubectl config use-context minikube
minikube status
kubectl get nodes
kubectl get pods -A
istioctl install --set profile=demo -y
kubectl label namespace default istio-injection=enabled --overwrite
kubectl get pods -n istio-system
```

Troubleshooting: Docker parado, rode `sudo service docker restart` (no WSL) ou abra Docker Desktop.  
Se o cluster corromper, `minikube delete && minikube start --driver=docker`.

---

## ✅ Etapa 2 — Microsserviços com Helm

Instale duas releases usando os values fornecidos:

```bash
helm lint techsafe-app
helm upgrade --install frontend ./techsafe-app -f values-frontend.yaml
helm upgrade --install usuarios ./techsafe-app -f values-usuarios.yaml
helm list
kubectl get pods,svc
```

Exponha via Istio:

```bash
kubectl apply -f istio/gateway.yaml
kubectl apply -f istio/virtualservice.yaml

# Se necessário, crie túnel para EXTERNAL-IP do istio-ingressgateway
minikube tunnel  # deixe em um terminal
kubectl -n istio-system get svc istio-ingressgateway
```

Edite `C:\Windows\System32\drivers\etc\hosts` e adicione:
```
<EXTERNAL-IP>  techsafe.local
```
Acesse no navegador / Postman:
- `http://techsafe.local/` → frontend
- `http://techsafe.local/usuarios/status/200` → usuarios

---

## ✅ Etapa 3 — Liveness Probes e Backup Automatizado

As **liveness/readiness probes** são configuráveis via `values.yaml` e já estão definidas nos deployments gerados pelo chart.

### Backup PostgreSQL (CronJob + PVC)

1) Crie o Secret a partir do template:  
Edite `k8s/backup/secret-db.template.yaml`, substitua os valores **base64**, e aplique:

```bash
kubectl apply -f k8s/backup/secret-db.template.yaml
kubectl apply -f k8s/backup/pvc.yaml
kubectl apply -f k8s/backup/cronjob-postgres-backup.yaml
```

2) Verifique a execução:
```bash
kubectl get cronjobs
kubectl get jobs -l app=postgres-backup
kubectl logs job/<NOME-DO-JOB> -f
kubectl get pods -l app=postgres-backup
```

Os backups são gravados em `/backup` dentro do pod, persistidos no PVC `postgres-backup-pvc`.

---

## 🧹 Limpeza / Destruir

```bash
./scripts/destroy.sh
```

---

## 📝 Observações

- As imagens de exemplo são **nginx** (frontend) e **kennethreitz/httpbin** (usuarios). Substitua por imagens reais quando desejar.
- O Istio é instalado no perfil **demo**. Para produção, ajuste o perfil e recursos.
- Todos os arquivos foram pensados para **VS Code no WSL** com extensões: Remote-WSL, YAML, Kubernetes, Docker e (opcional) Helm Intellisense.

Bom estudo e boa entrega! 🚀
